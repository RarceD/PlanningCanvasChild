(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-groups-groups-module"],{

/***/ "56b7":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/groups/groups.page.html ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title class=\"ion-text-center\"\n      >Select the group for this class:</ion-title\n    >\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-fab vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\">\n    <ion-fab-button routerLink=\"/classes\">\n      <ion-icon name=\"arrow-back\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n  <ion-fab vertical=\"top\" horizontal=\"end\" slot=\"fixed\">\n    <ion-fab-button>\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n    <ion-fab-list side=\"bottom\">\n      <ion-fab-button (click)=\"createGroup()\"color=\"success\"><ion-icon name=\"person-add\"></ion-icon></ion-fab-button>\n      <ion-fab-button (click)=\"removeGroup(null,false)\"color=\"danger\"><ion-icon name=\"person-remove-outline\"></ion-icon></ion-fab-button>\n    </ion-fab-list>\n  </ion-fab>\n  <ion-row>\n    <ul *ngFor=\"let g of groups index as i;\">\n      <ion-col>\n        <div\n          style=\"\n            height: 100%;\n            display: flex;\n            align-items: center;\n            justify-content: center;\n          \"\n        >\n          <ion-card>\n            <img src=\"{{g.image}}\" height=\"200\" width=\"180\"  routerLink=\"/schedule\" />\n            <ion-item  routerLink=\"/schedule\"class=\"ion-activated\">\n              <ion-card-title class=\"ion-text-center\">\n                Grupo {{g.name}}\n              </ion-card-title>\n            </ion-item>\n            <ion-card-content>\n              <ion-item>\n                <ion-button *ngIf=\"deleteGroup, else toDelete\" (click)=\"removeGroup(g, true)\" color=\"danger\">\n                  <ion-icon name=\"game-controller-outline\"></ion-icon>\n                  Delete\n                </ion-button>\n                <ng-template #toDelete>\n                  <ion-button  routerLink=\"/schedule\" color=\"success\">\n                    <ion-icon name=\"game-controller-outline\"></ion-icon>\n                    Let's go\n                  </ion-button>\n                </ng-template>\n              </ion-item>\n            </ion-card-content>\n          </ion-card>\n        </div>\n      </ion-col>\n    </ul>\n  </ion-row>\n</ion-content>\n");

/***/ }),

/***/ "OcId":
/*!*********************************************!*\
  !*** ./src/app/pages/groups/groups.page.ts ***!
  \*********************************************/
/*! exports provided: GroupsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GroupsPage", function() { return GroupsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_groups_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./groups.page.html */ "56b7");
/* harmony import */ var _groups_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./groups.page.scss */ "Op3+");
/* harmony import */ var _modal_create_group_create_group_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../modal/create-group/create-group.page */ "ZGPb");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_services_requests_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/requests.service */ "8aff");
/* harmony import */ var src_app_modal_class_verified_class_verified_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/modal/class-verified/class-verified.page */ "C9CL");








let GroupsPage = class GroupsPage {
    constructor(modalController, requestService) {
        this.modalController = modalController;
        this.requestService = requestService;
        this.groups = [
        // {
        //   id: 1,
        //   name: "Azules",
        //   image: "../../assets/images/group_1.svg",
        // },
        // {
        //   id: 2,
        //   name: "Violetas",
        //   image: "../../assets/images/group_2.svg",
        // },
        // {
        //   id: 3,
        //   name: "Rojo",
        //   image: "../../assets/images/group_3.svg",
        // },
        // {
        //   id: 4,
        //   name: "Verde",
        //   image: "../../assets/images/group_4.svg",
        // },
        ];
        this.deleteGroup = false;
    }
    ngOnInit() {
        this.obteidGroupsBackend();
    }
    obteidGroupsBackend() {
        this.requestService.getGroups().subscribe(data => {
            console.log(data);
            for (let g in data)
                this.groups.push(data[g]);
        }, err => console.error('Observer got an error: ' + err), () => console.log('Observer got a complete notification'));
    }
    createGroup() {
        this.createClass();
    }
    removeGroup(deleteGroupData, action) {
        let user = localStorage.getItem("user");
        if (user == "teacher") {
            this.deleteGroup = !this.deleteGroup;
            this.groups = this.groups.filter(obj => obj !== deleteGroupData);
            this.requestService.modifiedGroups(deleteGroupData, false);
            // if (action){
            //   this.verifiedIfTeacher("a", deleteGroupData);
            // }
        }
    }
    createClass() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _modal_create_group_create_group_page__WEBPACK_IMPORTED_MODULE_3__["CreateGroupPage"],
                cssClass: 'my-custom-class',
            });
            modal.onDidDismiss()
                .then((data) => {
                if (data['data'] != null) {
                    let g = data["data"];
                    this.groups.push(g);
                    this.requestService.modifiedGroups(g, true);
                }
                // this.classes.push(data['data']);
            });
            return yield modal.present();
        });
    }
    verifiedIfTeacher(pass, deleteGroupData) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: src_app_modal_class_verified_class_verified_page__WEBPACK_IMPORTED_MODULE_7__["ClassVerifiedPage"],
                cssClass: 'my-custom-class',
                componentProps: { 'truePassword': pass }
            });
            modal.onDidDismiss()
                .then((data) => {
                console.log(data['data']);
                if (data['data'] != null)
                    if (deleteGroupData != null) {
                        this.requestService.modifiedGroups(deleteGroupData, false);
                        this.groups = this.groups.filter(obj => obj !== deleteGroupData);
                    }
            });
            return yield modal.present();
        });
    }
};
GroupsPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"] },
    { type: src_app_services_requests_service__WEBPACK_IMPORTED_MODULE_6__["RequestsService"] }
];
GroupsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-groups',
        template: _raw_loader_groups_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_groups_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], GroupsPage);



/***/ }),

/***/ "Op3+":
/*!***********************************************!*\
  !*** ./src/app/pages/groups/groups.page.scss ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJncm91cHMucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "ak9z":
/*!***********************************************!*\
  !*** ./src/app/pages/groups/groups.module.ts ***!
  \***********************************************/
/*! exports provided: GroupsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GroupsPageModule", function() { return GroupsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _groups_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./groups-routing.module */ "jEu0");
/* harmony import */ var _groups_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./groups.page */ "OcId");







let GroupsPageModule = class GroupsPageModule {
};
GroupsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _groups_routing_module__WEBPACK_IMPORTED_MODULE_5__["GroupsPageRoutingModule"]
        ],
        declarations: [_groups_page__WEBPACK_IMPORTED_MODULE_6__["GroupsPage"]]
    })
], GroupsPageModule);



/***/ }),

/***/ "jEu0":
/*!*******************************************************!*\
  !*** ./src/app/pages/groups/groups-routing.module.ts ***!
  \*******************************************************/
/*! exports provided: GroupsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GroupsPageRoutingModule", function() { return GroupsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _groups_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./groups.page */ "OcId");




const routes = [
    {
        path: '',
        component: _groups_page__WEBPACK_IMPORTED_MODULE_3__["GroupsPage"]
    }
];
let GroupsPageRoutingModule = class GroupsPageRoutingModule {
};
GroupsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], GroupsPageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=pages-groups-groups-module.js.map