(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-classes-classes-module"],{

/***/ "4IPQ":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/classes/classes.page.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title  class=\"ion-text-center\" >Nombre de la aplicación</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <!-- fab placed in the center of the content with a list on each side -->\n  <ion-fab vertical=\"top\" horizontal=\"end\" slot=\"fixed\">\n    <ion-fab-button>\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n    <ion-fab-list side=\"bottom\">\n      <ion-fab-button (click)=\"createClass()\" color=\"success\"\n        ><ion-icon name=\"person-add\"></ion-icon\n      ></ion-fab-button>\n      <ion-fab-button (click)=\"removeClass(true)\" color=\"danger\"\n        ><ion-icon name=\"person-remove-outline\"></ion-icon\n      ></ion-fab-button>\n      <!-- <ion-fab-button (click)=\"removeClass(false)\" color=\"warning\"\n        ><ion-icon name=\"brush-outline\"></ion-icon\n      ></ion-fab-button> -->\n    </ion-fab-list>\n  </ion-fab>\n  <ion-row>\n    <ul *ngFor=\"let c of classes; index as i;\">\n      <ion-col>\n        <ion-card>\n          <img\n            (click)=\"selectClass(c)\"\n            src=\"{{c.image}}\"\n            height=\"200\"\n            width=\"180\"\n          />\n          <ion-item class=\"ion-activated\">\n            <ion-card-title> {{c.name}} </ion-card-title>\n            <ion-icon name=\"{{c.icon}}\" slot=\"start\"></ion-icon>\n          </ion-item>\n          <ion-card-content>\n            <ion-item *ngIf=\"showRemoveButton\">\n              <ion-button color=\"danger\" (click)=\"modifiedClasses(i, true)\">\n                <ion-icon name=\"search-outline\"></ion-icon>\n                Delete\n              </ion-button>\n            </ion-item>\n            <ion-item *ngIf=\"showEditButton\">\n              <ion-button color=\"warning\" (click)=\"modifiedClasses(i, false)\">\n                <ion-icon name=\"search-outline\"></ion-icon>\n                Edit Class\n              </ion-button>\n            </ion-item>\n          </ion-card-content>\n        </ion-card>\n      </ion-col>\n    </ul>\n  </ion-row>\n</ion-content>\n");

/***/ }),

/***/ "he2v":
/*!*********************************************************!*\
  !*** ./src/app/pages/classes/classes-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: ClassesPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClassesPageRoutingModule", function() { return ClassesPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _classes_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./classes.page */ "uCQa");




const routes = [
    {
        path: '',
        component: _classes_page__WEBPACK_IMPORTED_MODULE_3__["ClassesPage"]
    }
];
let ClassesPageRoutingModule = class ClassesPageRoutingModule {
};
ClassesPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ClassesPageRoutingModule);



/***/ }),

/***/ "sT57":
/*!*************************************************!*\
  !*** ./src/app/pages/classes/classes.module.ts ***!
  \*************************************************/
/*! exports provided: ClassesPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClassesPageModule", function() { return ClassesPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _classes_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./classes-routing.module */ "he2v");
/* harmony import */ var _classes_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./classes.page */ "uCQa");







let ClassesPageModule = class ClassesPageModule {
};
ClassesPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _classes_routing_module__WEBPACK_IMPORTED_MODULE_5__["ClassesPageRoutingModule"]
        ],
        declarations: [_classes_page__WEBPACK_IMPORTED_MODULE_6__["ClassesPage"]]
    })
], ClassesPageModule);



/***/ }),

/***/ "uCQa":
/*!***********************************************!*\
  !*** ./src/app/pages/classes/classes.page.ts ***!
  \***********************************************/
/*! exports provided: ClassesPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClassesPage", function() { return ClassesPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_classes_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./classes.page.html */ "4IPQ");
/* harmony import */ var _classes_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./classes.page.scss */ "wGGD");
/* harmony import */ var _services_requests_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../services/requests.service */ "8aff");
/* harmony import */ var _modal_create_class_create_class_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./../../modal/create-class/create-class.page */ "ZWKe");
/* harmony import */ var _modal_class_verified_class_verified_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./../../modal/class-verified/class-verified.page */ "C9CL");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "TEn/");








let ClassesPage = class ClassesPage {
    constructor(modalController, requestService) {
        this.modalController = modalController;
        this.requestService = requestService;
        this.classes = [
        // {
        //   id: 1,
        //   name: " 2ºA ",
        //   password: "a",
        //   image: "../../assets/images/class_e.svg",
        //   icon: "brush"
        // },
        // {
        //   id: 2,
        //   name: " 5ºB",
        //   password: "b",
        //   image: "../../assets/images/class_a.svg",
        //   icon: "aperture"
        // },
        // {
        //   id: 3,
        //   name: " 1ºB",
        //   password: "c",
        //   image: "../../assets/images/class_b.svg",
        //   icon: "paper-plane"
        // },
        // {
        //   id: 4,
        //   name: " 1ºB",
        //   password: "c",
        //   image: "../../assets/images/class_c.svg",
        //   icon: "color-palette"
        // },
        // {
        //   id: 5,
        //   name: " 4ºB",
        //   password: "d",
        //   image: "../../assets/images/class_d.svg",
        //   icon: "color-fill"
        // },
        // {
        //   id: 6,
        //   name: " 3ºA",
        //   password: "f",
        //   image: "../../assets/images/class_f.svg",
        //   icon: "color-fill"
        // },
        ];
        this.showRemoveButton = false;
        this.showEditButton = false;
    }
    ngOnInit() {
        this.obteidClassesBackend();
    }
    obteidClassesBackend() {
        this.requestService.getClass().subscribe(data => {
            console.log(data);
            for (let g in data) {
                // data[g].image = "../../assets/images/class_e.svg";
                this.classes.push(data[g]);
            }
        }, err => console.error('Observer got an error: ' + err), () => console.log('Observer got a complete notification'));
    }
    selectClass(classItem) {
        console.log(classItem);
        this.presentModal(classItem.password);
    }
    presentModal(pass) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _modal_class_verified_class_verified_page__WEBPACK_IMPORTED_MODULE_5__["ClassVerifiedPage"],
                cssClass: 'my-custom-class',
                componentProps: { 'truePassword': pass }
            });
            return yield modal.present();
        });
    }
    createClass() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            let user = localStorage.getItem("user");
            if (user == "teacher") {
                const modal = yield this.modalController.create({
                    component: _modal_create_class_create_class_page__WEBPACK_IMPORTED_MODULE_4__["CreateClassPage"],
                    cssClass: 'my-custom-class',
                    componentProps: {
                        'nop': 1
                    }
                });
                modal.onDidDismiss()
                    .then((data) => {
                    console.log(data['data']);
                    if (data['data'] != null)
                        this.classes.push(data['data']);
                    this.requestService.modifiedClass(data['data'], true);
                });
                return yield modal.present();
            }
        });
    }
    removeClass(deleteClass) {
        let user = localStorage.getItem("user");
        if (user == "teacher") {
            if (deleteClass)
                this.showRemoveButton = true;
            else
                this.showEditButton = true;
        }
    }
    modifiedClasses(item, deleteItem) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.showEditButton = false;
            this.showRemoveButton = false;
            if (deleteItem) {
                this.requestService.modifiedClass(this.classes[item], false);
                this.classes = this.classes.filter(obj => obj !== this.classes[item]);
            }
            else {
                const modal = yield this.modalController.create({
                    component: _modal_create_class_create_class_page__WEBPACK_IMPORTED_MODULE_4__["CreateClassPage"],
                    cssClass: 'my-custom-class',
                    componentProps: {
                        'classToEdit': this.classes[item]
                    }
                });
                modal.onDidDismiss()
                    .then((data) => {
                    console.log(data['data']);
                    if (data['data'] != null) {
                        let addMoreItem = true;
                        for (let c of this.classes) {
                            if (c.name == data['data'].name) {
                                c = data['data'];
                                addMoreItem = false;
                            }
                        }
                        if (addMoreItem) {
                            this.classes.push(data['data']);
                        }
                    }
                });
                return yield modal.present();
            }
        });
    }
};
ClassesPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ModalController"] },
    { type: _services_requests_service__WEBPACK_IMPORTED_MODULE_3__["RequestsService"] }
];
ClassesPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["Component"])({
        selector: 'app-classes',
        template: _raw_loader_classes_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_classes_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ClassesPage);



/***/ }),

/***/ "wGGD":
/*!*************************************************!*\
  !*** ./src/app/pages/classes/classes.page.scss ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-card {\n  display: flex;\n  flex-direction: column;\n  width: 100% !important;\n  margin: 0 !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjbGFzc2VzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7RUFDQSxzQkFBQTtFQUNBLHNCQUFBO0VBQ0Esb0JBQUE7QUFDRiIsImZpbGUiOiJjbGFzc2VzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jYXJke1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICB3aWR0aDogMTAwJSAhaW1wb3J0YW50O1xyXG4gIG1hcmdpbjogMCAhaW1wb3J0YW50O1xyXG59XHJcbiJdfQ== */");

/***/ })

}]);
//# sourceMappingURL=pages-classes-classes-module.js.map