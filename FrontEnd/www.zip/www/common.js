(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["common"],{

/***/ "0/6H":
/*!*********************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/button-active-a6787d69.js ***!
  \*********************************************************************/
/*! exports provided: c */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return createButtonActiveGesture; });
/* harmony import */ var _index_e806d1f6_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index-e806d1f6.js */ "A36C");
/* harmony import */ var _index_f49d994d_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index-f49d994d.js */ "iWo5");
/* harmony import */ var _haptic_27b3f981_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./haptic-27b3f981.js */ "qULd");




const createButtonActiveGesture = (el, isButton) => {
  let currentTouchedButton;
  let initialTouchedButton;
  const activateButtonAtPoint = (x, y, hapticFeedbackFn) => {
    if (typeof document === 'undefined') {
      return;
    }
    const target = document.elementFromPoint(x, y);
    if (!target || !isButton(target)) {
      clearActiveButton();
      return;
    }
    if (target !== currentTouchedButton) {
      clearActiveButton();
      setActiveButton(target, hapticFeedbackFn);
    }
  };
  const setActiveButton = (button, hapticFeedbackFn) => {
    currentTouchedButton = button;
    if (!initialTouchedButton) {
      initialTouchedButton = currentTouchedButton;
    }
    const buttonToModify = currentTouchedButton;
    Object(_index_e806d1f6_js__WEBPACK_IMPORTED_MODULE_0__["c"])(() => buttonToModify.classList.add('ion-activated'));
    hapticFeedbackFn();
  };
  const clearActiveButton = (dispatchClick = false) => {
    if (!currentTouchedButton) {
      return;
    }
    const buttonToModify = currentTouchedButton;
    Object(_index_e806d1f6_js__WEBPACK_IMPORTED_MODULE_0__["c"])(() => buttonToModify.classList.remove('ion-activated'));
    /**
     * Clicking on one button, but releasing on another button
     * does not dispatch a click event in browsers, so we
     * need to do it manually here. Some browsers will
     * dispatch a click if clicking on one button, dragging over
     * another button, and releasing on the original button. In that
     * case, we need to make sure we do not cause a double click there.
     */
    if (dispatchClick && initialTouchedButton !== currentTouchedButton) {
      currentTouchedButton.click();
    }
    currentTouchedButton = undefined;
  };
  return Object(_index_f49d994d_js__WEBPACK_IMPORTED_MODULE_1__["createGesture"])({
    el,
    gestureName: 'buttonActiveDrag',
    threshold: 0,
    onStart: ev => activateButtonAtPoint(ev.currentX, ev.currentY, _haptic_27b3f981_js__WEBPACK_IMPORTED_MODULE_2__["a"]),
    onMove: ev => activateButtonAtPoint(ev.currentX, ev.currentY, _haptic_27b3f981_js__WEBPACK_IMPORTED_MODULE_2__["b"]),
    onEnd: () => {
      clearActiveButton(true);
      Object(_haptic_27b3f981_js__WEBPACK_IMPORTED_MODULE_2__["h"])();
      initialTouchedButton = undefined;
    }
  });
};




/***/ }),

/***/ "74mu":
/*!*************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/theme-ff3fc52f.js ***!
  \*************************************************************/
/*! exports provided: c, g, h, o */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return createColorClasses; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "g", function() { return getClassMap; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "h", function() { return hostContext; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "o", function() { return openURL; });
const hostContext = (selector, el) => {
  return el.closest(selector) !== null;
};
/**
 * Create the mode and color classes for the component based on the classes passed in
 */
const createColorClasses = (color, cssClassMap) => {
  return (typeof color === 'string' && color.length > 0) ? Object.assign({ 'ion-color': true, [`ion-color-${color}`]: true }, cssClassMap) : cssClassMap;
};
const getClassList = (classes) => {
  if (classes !== undefined) {
    const array = Array.isArray(classes) ? classes : classes.split(' ');
    return array
      .filter(c => c != null)
      .map(c => c.trim())
      .filter(c => c !== '');
  }
  return [];
};
const getClassMap = (classes) => {
  const map = {};
  getClassList(classes).forEach(c => map[c] = true);
  return map;
};
const SCHEME = /^[a-z][a-z0-9+\-.]*:/;
const openURL = async (url, ev, direction, animation) => {
  if (url != null && url[0] !== '#' && !SCHEME.test(url)) {
    const router = document.querySelector('ion-router');
    if (router) {
      if (ev != null) {
        ev.preventDefault();
      }
      return router.push(url, direction, animation);
    }
  }
  return false;
};




/***/ }),

/***/ "8aff":
/*!**********************************************!*\
  !*** ./src/app/services/requests.service.ts ***!
  \**********************************************/
/*! exports provided: RequestsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RequestsService", function() { return RequestsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "tk/3");



let RequestsService = class RequestsService {
    constructor(http) {
        this.http = http;
        //I get the groups from DB:
        // public urlGet = "https://localhost:5002";
        this.urlGet = "https://81.46.227.112:5002";
    }
    getClass() {
        let url = this.urlGet + "/classes";
        return this.http.get(url);
    }
    modifiedClass(postData, add) {
        let url = this.urlGet + "/classes";
        if (add)
            url += "/add";
        else
            url += "/delete";
        this.http.post(url, postData).subscribe(data => {
        });
    }
    getGroups() {
        let url = this.urlGet + "/groups";
        return this.http.get(url);
    }
    modifiedGroups(postData, add) {
        let url = this.urlGet + "/groups";
        if (add)
            url += "/add";
        else
            url += "/delete";
        console.log(url, postData);
        this.http.post(url, postData).subscribe();
    }
    getTasks() {
        let url = this.urlGet + "/tasks";
        return this.http.get(url);
    }
    modifiedTasks(postData, add) {
        let url = this.urlGet + "/tasks";
        if (add)
            url += "/add";
        else
            url += "/delete";
        console.log(url, postData);
        this.http.post(url, postData).subscribe();
    }
};
RequestsService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
RequestsService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], RequestsService);



/***/ }),

/***/ "C9CL":
/*!*************************************************************!*\
  !*** ./src/app/modal/class-verified/class-verified.page.ts ***!
  \*************************************************************/
/*! exports provided: ClassVerifiedPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClassVerifiedPage", function() { return ClassVerifiedPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_class_verified_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./class-verified.page.html */ "l8hp");
/* harmony import */ var _class_verified_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./class-verified.page.scss */ "kn/A");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");






let ClassVerifiedPage = class ClassVerifiedPage {
    constructor(modalController, router, toastController) {
        this.modalController = modalController;
        this.router = router;
        this.toastController = toastController;
        this.imageSecure = "../../assets/images/security.svg";
    }
    ngOnInit() {
    }
    dismiss() {
        // using the injected ModalController this page
        // can "dismiss" itself and optionally pass back data
        this.modalController.dismiss({
            'dismissed': true
        });
    }
    checkSubmission() {
        // console.log(this.userPass, this.truePassword);
        if (this.userPass == this.truePassword) {
            console.log("Match the pass");
            this.router.navigate(['/groups']);
            this.dismiss();
        }
        else if (this.userPass == "teacher") {
            console.log("You are the teacher");
            localStorage.setItem("user", "teacher");
            this.router.navigate(['/classes']);
            this.dismiss();
        }
        else {
            this.presentToast();
            this.dismiss();
        }
    }
    presentToast() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                header: 'WRONG PASSWORDS',
                message: 'Please try one more time',
                position: 'top',
                duration: 2000
            });
            toast.present();
        });
    }
};
ClassVerifiedPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] }
];
ClassVerifiedPage.propDecorators = {
    truePassword: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
ClassVerifiedPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-class-verified',
        template: _raw_loader_class_verified_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_class_verified_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ClassVerifiedPage);



/***/ }),

/***/ "HETJ":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/modal/create-task/create-task.page.html ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title class=\"ion-text-center\">Create a new task</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-item>\n    <ion-label> Introduce the main task: </ion-label>\n  </ion-item>\n  <ion-input [(ngModel)]=\"task.text\" placeholder=\"Enter task name\"></ion-input>\n  <ion-row>\n    <ion-col>\n      <ion-input [(ngModel)]=\"task.start\" placeholder=\"Start day\"></ion-input>\n    </ion-col>\n    <ion-col>\n      <ion-input [(ngModel)]=\"task.end\" placeholder=\"End task\"></ion-input>\n    </ion-col>\n  </ion-row>\n  <ion-item>\n    <ion-label> Introduce the second tasks: </ion-label>\n  </ion-item>\n  <ion-input\n    [(ngModel)]=\"secondTask.text\"\n    placeholder=\"Enter second task name\"\n  ></ion-input>\n  <ion-input\n    [(ngModel)]=\"secondTask.child_name\"\n    placeholder=\"Child name\"\n  ></ion-input>\n  <ion-row>\n    <ion-col>\n      <ion-input\n        [(ngModel)]=\"secondTask.start\"\n        placeholder=\"Start day\"\n      ></ion-input>\n    </ion-col>\n    <ion-col>\n      <ion-input\n        [(ngModel)]=\"secondTask.end\"\n        placeholder=\"End task\"\n      ></ion-input>\n    </ion-col>\n  </ion-row>\n  <ion-button expand=\"full\" (click)=\"addSecondTasks()\" color=\"medium\"\n    >Add second tasks\n  </ion-button>\n  <ion-item>\n    <ion-label> Second task associated to the main </ion-label>\n  </ion-item>\n  <ul *ngFor=\"let t of task.associatedTasks\">\n    <ion-item>\n      <ion-label class=\"ion-text-wrap\"> {{t.text}} </ion-label>\n      <ion-col> Start: {{t.start}} </ion-col>\n      <ion-col> End: {{t.end}} </ion-col>\n      <ion-note>{{t.child_name}} </ion-note>\n      <ion-button (click)=\"removeSecondTask(t)\" color=\"danger\"> X </ion-button>\n    </ion-item>\n  </ul>\n  <section>\n    <ion-row>\n      <ion-col>\n        <ion-button expand=\"full\" color=\"success\" (click)=\"dismiss(true)\"\n          >Save new task</ion-button\n        >\n      </ion-col>\n      <ion-col>\n        <ion-button expand=\"full\" color=\"danger\" (click)=\"dismiss(false)\"\n          >Close editing task\n        </ion-button>\n      </ion-col>\n    </ion-row>\n  </section>\n</ion-content>\n");

/***/ }),

/***/ "Ub2D":
/*!***********************************************************!*\
  !*** ./src/app/modal/create-group/create-group.page.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjcmVhdGUtZ3JvdXAucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "ZGPb":
/*!*********************************************************!*\
  !*** ./src/app/modal/create-group/create-group.page.ts ***!
  \*********************************************************/
/*! exports provided: CreateGroupPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateGroupPage", function() { return CreateGroupPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_create_group_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./create-group.page.html */ "jixU");
/* harmony import */ var _create_group_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./create-group.page.scss */ "Ub2D");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");





let CreateGroupPage = class CreateGroupPage {
    constructor(modalController, toastController) {
        this.modalController = modalController;
        this.toastController = toastController;
        this.group = {
            id: 1,
            image: "",
            name: ""
        };
        this.teacherPassword = "";
    }
    ngOnInit() {
    }
    dismiss(action) {
        if (action) {
            if (this.teacherPassword == "teacher")
                this.modalController.dismiss(this.group);
            else
                this.presentToast();
        }
        this.modalController.dismiss();
    }
    presentToast() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                header: 'WRONG PASSWORDS',
                message: 'You are not the teacher',
                position: 'top',
                duration: 2000
            });
            toast.present();
        });
    }
};
CreateGroupPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"] }
];
CreateGroupPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-create-group',
        template: _raw_loader_create_group_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_create_group_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], CreateGroupPage);



/***/ }),

/***/ "ZWKe":
/*!*********************************************************!*\
  !*** ./src/app/modal/create-class/create-class.page.ts ***!
  \*********************************************************/
/*! exports provided: CreateClassPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateClassPage", function() { return CreateClassPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_create_class_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./create-class.page.html */ "gpk2");
/* harmony import */ var _create_class_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./create-class.page.scss */ "z/qL");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");





let CreateClassPage = class CreateClassPage {
    constructor(modalController) {
        this.modalController = modalController;
        this.class = {
            icon: "",
            id: 0,
            image: "",
            name: "",
            password: "",
        };
    }
    ngOnInit() {
        console.log(this.classToEdit);
        if (this.classToEdit != null)
            this.class = this.classToEdit;
    }
    dismiss(action) {
        if (action) {
            if (this.classToEdit == null) {
                this.class.image = "../../assets/images/class_e.svg";
                this.class.icon = "add";
            }
            else {
                this.classToEdit = this.class;
            }
            this.modalController.dismiss(this.class);
        }
        this.modalController.dismiss();
    }
};
CreateClassPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] }
];
CreateClassPage.propDecorators = {
    classToEdit: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
CreateClassPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-create-class',
        template: _raw_loader_create_class_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_create_class_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], CreateClassPage);



/***/ }),

/***/ "ZaV5":
/*!**************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/framework-delegate-4584ab5a.js ***!
  \**************************************************************************/
/*! exports provided: a, d */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return attachComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return detachComponent; });
const attachComponent = async (delegate, container, component, cssClasses, componentProps) => {
  if (delegate) {
    return delegate.attachViewToDom(container, component, componentProps, cssClasses);
  }
  if (typeof component !== 'string' && !(component instanceof HTMLElement)) {
    throw new Error('framework delegate is missing');
  }
  const el = (typeof component === 'string')
    ? container.ownerDocument && container.ownerDocument.createElement(component)
    : component;
  if (cssClasses) {
    cssClasses.forEach(c => el.classList.add(c));
  }
  if (componentProps) {
    Object.assign(el, componentProps);
  }
  container.appendChild(el);
  if (el.componentOnReady) {
    await el.componentOnReady();
  }
  return el;
};
const detachComponent = (delegate, element) => {
  if (element) {
    if (delegate) {
      const container = element.parentElement;
      return delegate.removeViewFromDom(container, element);
    }
    element.remove();
  }
  return Promise.resolve();
};




/***/ }),

/***/ "dd0/":
/*!*******************************************************!*\
  !*** ./src/app/modal/create-task/create-task.page.ts ***!
  \*******************************************************/
/*! exports provided: CreateTaskPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateTaskPage", function() { return CreateTaskPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_create_task_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./create-task.page.html */ "HETJ");
/* harmony import */ var _create_task_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./create-task.page.scss */ "rtLM");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");





let CreateTaskPage = class CreateTaskPage {
    constructor(modalController) {
        this.modalController = modalController;
        this.task = {
            id: 1,
            start: null,
            text: "",
            associatedTasks: [
            // {
            //   text:"tarea secundaria 1",
            //   child_name:"niñoMierdas",
            //   start: 1,
            //   end: 5
            // },
            // {
            //   text:"tarea secundaria 2",
            //   child_name:"niñoMierdas2",
            //   start: 2,
            //   end: 8
            // }
            ],
            end: null,
        };
        this.secondTask = {
            text: "",
            child_name: "",
            start: null,
            end: null
        };
    }
    ngOnInit() {
    }
    dismiss(action) {
        if (action) {
            this.modalController.dismiss(this.task);
        }
        else {
            this.modalController.dismiss();
        }
    }
    addSecondTasks() {
        this.task.associatedTasks.push(this.secondTask);
        this.secondTask = {
            text: "",
            child_name: "",
            start: null,
            end: null
        };
    }
    removeSecondTask(deleteTask) {
        this.task.associatedTasks = this.task.associatedTasks.filter(obj => obj !== deleteTask);
    }
};
CreateTaskPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] }
];
CreateTaskPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-create-task',
        template: _raw_loader_create_task_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_create_task_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], CreateTaskPage);



/***/ }),

/***/ "gpk2":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/modal/create-class/create-class.page.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title> Create new class in school</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-item>\n    <ion-label> Introduce the name and pass: </ion-label>\n  </ion-item>\n  <ion-input\n    [(ngModel)]=\"class.name\"\n    placeholder=\"Enter class name\"\n  ></ion-input>\n  <ion-input [(ngModel)]=\"class.password\" placeholder=\"Password\"></ion-input>\n  <ion-item>\n    <ion-label> Introduce the image and icon from ionic: </ion-label>\n  </ion-item>\n  <ion-input\n    [(ngModel)]=\"class.image\"\n    placeholder=\"Enter image url\"\n  ></ion-input>\n  <ion-input\n    [(ngModel)]=\"class.icon\"\n    placeholder=\"Enter icon to show\"\n  ></ion-input>\n  <section>\n    <ion-row>\n      <ion-col>\n        <ion-button expand=\"full\" color=\"success\" (click)=\"dismiss(true)\"\n          >Save new class</ion-button\n        >\n      </ion-col>\n      <ion-col>\n        <ion-button expand=\"full\" color=\"danger\" (click)=\"dismiss(false)\"\n          >Close editing\n        </ion-button>\n      </ion-col>\n    </ion-row>\n  </section>\n</ion-content>\n");

/***/ }),

/***/ "h3R7":
/*!***********************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/spinner-configs-cd7845af.js ***!
  \***********************************************************************/
/*! exports provided: S */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "S", function() { return SPINNERS; });
const spinners = {
  'bubbles': {
    dur: 1000,
    circles: 9,
    fn: (dur, index, total) => {
      const animationDelay = `${(dur * index / total) - dur}ms`;
      const angle = 2 * Math.PI * index / total;
      return {
        r: 5,
        style: {
          'top': `${9 * Math.sin(angle)}px`,
          'left': `${9 * Math.cos(angle)}px`,
          'animation-delay': animationDelay,
        }
      };
    }
  },
  'circles': {
    dur: 1000,
    circles: 8,
    fn: (dur, index, total) => {
      const step = index / total;
      const animationDelay = `${(dur * step) - dur}ms`;
      const angle = 2 * Math.PI * step;
      return {
        r: 5,
        style: {
          'top': `${9 * Math.sin(angle)}px`,
          'left': `${9 * Math.cos(angle)}px`,
          'animation-delay': animationDelay,
        }
      };
    }
  },
  'circular': {
    dur: 1400,
    elmDuration: true,
    circles: 1,
    fn: () => {
      return {
        r: 20,
        cx: 48,
        cy: 48,
        fill: 'none',
        viewBox: '24 24 48 48',
        transform: 'translate(0,0)',
        style: {}
      };
    }
  },
  'crescent': {
    dur: 750,
    circles: 1,
    fn: () => {
      return {
        r: 26,
        style: {}
      };
    }
  },
  'dots': {
    dur: 750,
    circles: 3,
    fn: (_, index) => {
      const animationDelay = -(110 * index) + 'ms';
      return {
        r: 6,
        style: {
          'left': `${9 - (9 * index)}px`,
          'animation-delay': animationDelay,
        }
      };
    }
  },
  'lines': {
    dur: 1000,
    lines: 12,
    fn: (dur, index, total) => {
      const transform = `rotate(${30 * index + (index < 6 ? 180 : -180)}deg)`;
      const animationDelay = `${(dur * index / total) - dur}ms`;
      return {
        y1: 17,
        y2: 29,
        style: {
          'transform': transform,
          'animation-delay': animationDelay,
        }
      };
    }
  },
  'lines-small': {
    dur: 1000,
    lines: 12,
    fn: (dur, index, total) => {
      const transform = `rotate(${30 * index + (index < 6 ? 180 : -180)}deg)`;
      const animationDelay = `${(dur * index / total) - dur}ms`;
      return {
        y1: 12,
        y2: 20,
        style: {
          'transform': transform,
          'animation-delay': animationDelay,
        }
      };
    }
  }
};
const SPINNERS = spinners;




/***/ }),

/***/ "jixU":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/modal/create-group/create-group.page.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title> Create new group in class</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-item>\n    <ion-label> Introduce the name of the new group: </ion-label>\n  </ion-item>\n  <ion-input\n    [(ngModel)]=\"group.name\"\n    placeholder=\"Enter class name\"\n  ></ion-input>\n  <ion-input\n    [(ngModel)]=\"group.image\"\n    placeholder=\"Image to show\"\n  ></ion-input>\n  <ion-item>\n    <ion-label> Groups can only be created by teacher </ion-label>\n  </ion-item>\n  <ion-input\n    [(ngModel)]=\"teacherPassword\"\n    placeholder=\"Teacher password\"\n  ></ion-input>\n\n  <section>\n    <ion-row>\n      <ion-col>\n        <ion-button expand=\"full\" color=\"success\" (click)=\"dismiss(true)\"\n          >Save new class</ion-button\n        >\n      </ion-col>\n      <ion-col>\n        <ion-button expand=\"full\" color=\"danger\" (click)=\"dismiss(false)\"\n          >Close editing\n        </ion-button>\n      </ion-col>\n    </ion-row>\n  </section>\n</ion-content>\n");

/***/ }),

/***/ "kn/A":
/*!***************************************************************!*\
  !*** ./src/app/modal/class-verified/class-verified.page.scss ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".center {\n  display: flex;\n  justify-content: center;\n  align-content: center;\n  align-items: center;\n  width: 50%;\n}\n\n.centerLogin {\n  width: 500px;\n  margin: auto;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjbGFzcy12ZXJpZmllZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxxQkFBQTtFQUNBLG1CQUFBO0VBQ0EsVUFBQTtBQUNGOztBQUVBO0VBQ0UsWUFBQTtFQUNBLFlBQUE7QUFDRiIsImZpbGUiOiJjbGFzcy12ZXJpZmllZC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY2VudGVyIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGFsaWduLWNvbnRlbnQ6IGNlbnRlcjtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIHdpZHRoOiA1MCU7XHJcbn1cclxuXHJcbi5jZW50ZXJMb2dpbiB7XHJcbiAgd2lkdGg6IDUwMHB4O1xyXG4gIG1hcmdpbjogYXV0b1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ "l8hp":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/modal/class-verified/class-verified.page.html ***!
  \*****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>Introduce the password for your class</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-card class=\"centerLogin\">\n    <img class=\"centerLogin\" src=\"{{imageSecure}}\" height=\"200\" width=\"200\" />\n  </ion-card>\n  <ion-input [(ngModel)]=\"userPass\" placeholder=\"Enter Password\"></ion-input>\n<ion-row>\n\n  <ion-col>\n    <ion-button (click)=\"checkSubmission()\" expand=\"full\" \n    >Submit Password</ion-button\n    >\n  </ion-col>\n  <ion-col>\n    <ion-button (click)=\"dismiss()\" expand=\"full\" color=\"danger\"\n    >Exit submission</ion-button\n    >\n  </ion-col>\n</ion-row>\n</ion-content>\n");

/***/ }),

/***/ "qULd":
/*!**************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/haptic-27b3f981.js ***!
  \**************************************************************/
/*! exports provided: a, b, c, d, h */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return hapticSelectionStart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return hapticSelectionChanged; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return hapticSelection; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return hapticImpact; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "h", function() { return hapticSelectionEnd; });
const HapticEngine = {
  getEngine() {
    const win = window;
    return (win.TapticEngine) || (win.Capacitor && win.Capacitor.isPluginAvailable('Haptics') && win.Capacitor.Plugins.Haptics);
  },
  available() {
    return !!this.getEngine();
  },
  isCordova() {
    return !!window.TapticEngine;
  },
  isCapacitor() {
    const win = window;
    return !!win.Capacitor;
  },
  impact(options) {
    const engine = this.getEngine();
    if (!engine) {
      return;
    }
    const style = this.isCapacitor() ? options.style.toUpperCase() : options.style;
    engine.impact({ style });
  },
  notification(options) {
    const engine = this.getEngine();
    if (!engine) {
      return;
    }
    const style = this.isCapacitor() ? options.style.toUpperCase() : options.style;
    engine.notification({ style });
  },
  selection() {
    this.impact({ style: 'light' });
  },
  selectionStart() {
    const engine = this.getEngine();
    if (!engine) {
      return;
    }
    if (this.isCapacitor()) {
      engine.selectionStart();
    }
    else {
      engine.gestureSelectionStart();
    }
  },
  selectionChanged() {
    const engine = this.getEngine();
    if (!engine) {
      return;
    }
    if (this.isCapacitor()) {
      engine.selectionChanged();
    }
    else {
      engine.gestureSelectionChanged();
    }
  },
  selectionEnd() {
    const engine = this.getEngine();
    if (!engine) {
      return;
    }
    if (this.isCapacitor()) {
      engine.selectionEnd();
    }
    else {
      engine.gestureSelectionEnd();
    }
  }
};
/**
 * Trigger a selection changed haptic event. Good for one-time events
 * (not for gestures)
 */
const hapticSelection = () => {
  HapticEngine.selection();
};
/**
 * Tell the haptic engine that a gesture for a selection change is starting.
 */
const hapticSelectionStart = () => {
  HapticEngine.selectionStart();
};
/**
 * Tell the haptic engine that a selection changed during a gesture.
 */
const hapticSelectionChanged = () => {
  HapticEngine.selectionChanged();
};
/**
 * Tell the haptic engine we are done with a gesture. This needs to be
 * called lest resources are not properly recycled.
 */
const hapticSelectionEnd = () => {
  HapticEngine.selectionEnd();
};
/**
 * Use this to indicate success/failure/warning to the user.
 * options should be of the type `{ style: 'light' }` (or `medium`/`heavy`)
 */
const hapticImpact = (options) => {
  HapticEngine.impact(options);
};




/***/ }),

/***/ "rtLM":
/*!*********************************************************!*\
  !*** ./src/app/modal/create-task/create-task.page.scss ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjcmVhdGUtdGFzay5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "z/qL":
/*!***********************************************************!*\
  !*** ./src/app/modal/create-class/create-class.page.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjcmVhdGUtY2xhc3MucGFnZS5zY3NzIn0= */");

/***/ })

}]);
//# sourceMappingURL=common.js.map